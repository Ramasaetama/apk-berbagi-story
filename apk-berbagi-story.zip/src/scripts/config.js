const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  DEFAULT_MAP_CENTER: [-6.2, 106.816666], // Jakarta
  DEFAULT_MAP_ZOOM: 5,
};

export default CONFIG;
